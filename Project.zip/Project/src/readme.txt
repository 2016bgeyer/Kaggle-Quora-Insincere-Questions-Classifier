Benjamin Geyer
Phillip Pascal
neural_network_kaggle_submission.py : the final NN code used on the kaggel kernel to create a submission on kaggle

multiple_models.py : Our local testing data set for all the models, NN code isn't as up to date a kaggle python file

crawler : original failed project code that we didn't finish. This is a web crawler.


Kaggle Competition with the Datasets:
https://www.kaggle.com/c/quora-insincere-questions-classification