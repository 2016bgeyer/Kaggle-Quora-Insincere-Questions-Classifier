const puppeteer = require('puppeteer');
(async () => {
	try {




		const browser = await puppeteer.launch({
				headless: false,
				args: [`--window-size=${1920},${1080}`,
					'--disable-web-security',],
			}
		);
		const page = await browser.newPage();
		// log browser console to your local console
		// page.on('console', consoleObj => console.log(consoleObj.text()));

		await page.setViewport({ width: 1920, height: 1080 })

		// Pass the Webdriver Test.
		await page.evaluateOnNewDocument(() => {
			Object.defineProperty(navigator, 'webdriver', {
				get: () => false,
			});
			// Overwrite the `plugins` property to use a custom getter.
			Object.defineProperty(navigator, 'plugins', {
				// This just needs to have `length > 0` for the current test,
				// but we could mock the plugins too if necessary.
				get: () => [1, 2, 3, 4, 5],
			});
			// Overwrite the `plugins` property to use a custom getter.
			Object.defineProperty(navigator, 'languages', {
				get: () => ['en-US', 'en'],
			});
		});

		const debug = false;
		const tab = false;
		let websites = [
			// 'https://twitter.com',
			'https://reddit.com',
			// 'https://old.reddit.com',
			// 'https://cnn.com',
			// 'https://msnbc.com',
			// 'https://foxnews.com',
			// 'https://news.yahoo.com/',
			// 'https://www.huffpost.com/',
			// 'https://www.nytimes.com/',
			// 'https://www.nbcnews.com/',
			// 'https://www.usatoday.com/'
		];
		let hangtime = 3000;   		// ten second wait on each page
		let numClicksPerSite = 30; 	// Clicks per site before going to next site
		let minBrowseTime = 30 		// seconds of browsing per page
		let maxBrowseTime = 60 		// seconds of browsing per page

		
		const browseTime = (start) => {
			time = (new Date() - start) / 1000 	// remove ms
			console.log('time diff: ', time)
			return time;
		}
	
		// process custom command line args
		if (process.argv.length > 2) {
			let argArray = process.argv;
			argArray.splice(0, 2);
			websites = [];
			for (const arg of argArray) {
				if (!isNaN(parseInt(arg))) {
					hangtime = parseInt(arg);
					console.log(hangtime);
				} else {
					websites.push(arg);
					console.log(websites);
				}
			}
		}

		selectors = [
			'a',
			'#tweet-rich-content-label',
			'#tweet-action-buttons',
			'.tweet',
			'button',
			'textarea',
			'.up',
			'.down',
			'[role="button"]',
		];
		typingSelectors = [
			'input[type="email"]',
			'input[type="username"]',
			'input[type="password"]',
		];
		bannedValues = [
			'Log in',
			'Sign Up',
			'Contact Us',
			'Contact',
			'Forgot Password',
			'Forgot Password?',
			'Reset Password',
			'Register Now'
		];
		bannedPropertiesToCheck = [
			'innerText',
			'text',
			'innerText',
			'textContent',
		];
		propertiesToScrape = [
			'href',
			'name',
			'text',
			'innerText',
			'textContent',
		];
		requireSignOn = [
			'Share',
			'Reply',
			'Comment',
		];
		browser.on("targetcreated", async (target)=>{
			const page=await target.page();
			if(page) page.close();
		});
		for (const website of websites) {
			console.log(`navigating to ${website}`);
			await page.goto(website).then().catch((err) => {
				console.log(`Navigation Error "${err}" is it possible website "${website}" was mistyped`);
			});
			// need to try mistyping URL
			// await page.screenshot({ path: 'example.png' });

			console.log('Overridding Notification permisssions to block the popup');
			const context = browser.defaultBrowserContext();
			await context.overridePermissions(page.url(), ['notifications']);

			const startTime = new Date();


			// console.log("new URL(Window.location).origin: ", new URL(Window.location).origin);
			if (debug) {
				page.on('console', message =>{
					if (!message.text().includes('A cookie associated')) { // ignore annoying chromium error message
						console.log(`${message.type().substr(0, 3).toUpperCase()}: \n${message.text()}`)
					}
				})
					.on('pageerror', ({ message }) => console.log(message))
					.on('requestfailed', request =>
						console.log(`${request.failure().errorText} ${request.url()}`))
				// .on('response', response =>
				// console.log(`${response.status()} ${response.url()}`))
			}

			async function scrapeElements(selectors, bannedValues, bannedPropertiesToCheck, propertiesToScrape) {
				console.log('selectors: ', selectors);

				retElements = [];
				console.log('selectors: ', selectors);
				async function formatter(item, propertiesToScrape) {
					result = {'selector': selector};
					for (const prop of propertiesToScrape) {
						const json =  await item.getProperty(prop.toLowerCase());
						const value = await json.jsonValue();
						result[prop] = value;
					}
					return result;
				}
				
				async function customFilter(arr, callback) {
					// custom asynchronous filter helper
					const fail = Symbol()
					return (await Promise.all(arr.map(async item => (await callback(item)) ? item : fail))).filter(i=>i!==fail)
				}
				const isBannedElement = async function(element, bannedValues, bannedPropertiesToCheck) {
					for(let prop of bannedPropertiesToCheck) {
						let elementValue;
						let validValue = false;
						try {
							elementValue = await element.getProperty(prop);
							elementValue = await elementValue.jsonValue();
							if(elementValue !== undefined) {
								validValue = true;
							}
						}
						catch{
							validValue = false;
						}
						for(let value of bannedValues) {
							try {
								if (validValue && elementValue.toLowerCase().includes(value.toLowerCase())) {
									console.log(`Element contains banned prop: ${prop}: value: ${value}`)
									return true;
								}						
							}
							catch(err) {
								console.log(err);
								continue;
							}	
						}
					}
					return false;
				}
				for (selector of selectors) {
					console.log('Selector: ', selector);
					var selectedElements;
					if (selector == 'a') {
						let tempElements = await page.$$(selector);
						console.log(`tempElements length before: ${tempElements.length}`);
						selectedElements = await customFilter(tempElements, async a => {
							try {
								if (a !== undefined) {
									let banned = await isBannedElement(a, bannedValues, bannedPropertiesToCheck)
									if (banned === true) // || a.href.includes(' ')) // remove "javascript (void 0);"
									{
										console.log('banned link');
										return false;
									}
									else {
										return true;
									}
								} else {
									console.log('invalid link: ', a);
									return false;
								}
							} catch(err) {
								console.log('some link error:', err);
								return false;
							}
						});
						console.log(`selectedElements length after: ${await selectedElements.length}`);
					}
					else {
						selectedElements = await customFilter(await page.$$(selector), async a => {
							!(await isBannedElement(a, bannedValues, bannedPropertiesToCheck))
						});
					}
					console.log(`length of selectedElements from ${selector}: ${selectedElements.length}`);
					retElements = retElements.concat(selectedElements);
					console.log('new retElements.length: ', retElements.length);
				}
				console.log(`length returning retElements: ${retElements.length}`);
				return retElements;
			}


			let iter = 0;
			while ((iter < numClicksPerSite || browseTime(startTime) < minBrowseTime) && browseTime(startTime) < maxBrowseTime) {
				iter++;
				// now wait
				// const time = await Promise.resolve((Math.floor(Math.random() * (5 - 1)) + 1) * 1000);
				const time = hangtime;
				console.log(`visiting for ${time} seconds`);
				// await Promise.resolve(setTimeout(() => {
				// 	console.log(`visiting for ${time/1000} second(s)`);
				// }, time));
				await page.waitFor(time);
				console.log('\nDone waiting');


				var pageElements = await scrapeElements(selectors, bannedValues, bannedPropertiesToCheck, propertiesToScrape);
				// var pageElements = scrapeElements(selectors, bannedValues, bannedPropertiesToCheck, propertiesToScrape);
				console.log(pageElements.length);
				console.log(`length returned pageElements: ${pageElements.length}`);

				// Complex elements click
				console.log('pageElements.length: ', pageElements.length);
				if (pageElements.length > 0) {
					var itemIndex = -1;
					var repeat = true;

					// need to break out of infinite loop
					while(repeat){
						itemIndex = Math.floor(Math.random() * (pageElements.length - 1)); // randomly choose button to click on
						if (await pageElements[itemIndex].isIntersectingViewport()) {
							repeat = false;
						}
						else {
							console.log(`Index ${itemIndex} was not visible`)
						}
					}
					var href = 'None';
					if (pageElements[itemIndex] && pageElements[itemIndex].hasOwnProperty('href')) {
						href = pageElements[itemIndex].href;
					}
					console.log(`CURRENTLY AT: ${page.url()}\nCLICKING: ${pageElements[itemIndex]}\nIndex: ${itemIndex}`);
					if (href) {
						console.log(`\nHREF: ${href}`);
					}
					try{
						// var innerText = pageElements[itemIndex].innerText;
						const innerText = await (await pageElements[itemIndex].getProperty('innerText')).jsonValue();
						console.log(`\ninnerText: ${innerText}`);
					}
					catch {
						continue
					}
					// await pageElements[itemIndex].focus();
					try {
						await pageElements[itemIndex].click();
					}
					catch (err) {
						console.log(`Element Click Error: \n"${err}"`);
						await page.goBack();
					}
					console.log(`waiting for ${hangtime}`)
					await page.waitFor(hangtime);
				}

				// console.log('visit two links now');
				// for (let i = 0; i <= 2; i++) {
				//     const page2 = await browser.newPage();
				//     const linkIndex = Math.floor(Math.random() * (pageLinks.length - 1)); // randomly choose site to go to
				//     console.log(`link index ${linkIndex}, value= ${pageLinks[linkIndex]}`);
				//     await page2.goto(pageLinks[linkIndex]);
				//     console.log('visit between 1 and 5 seconds');
				//     const time = await Promise.resolve((Math.floor(Math.random() * (5 - 1)) + 1) * 1000);
				//     // const time = hangtime;
				//     await Promise.resolve(setTimeout(() => {
				//         console.log(`visiting for ${time/1000} second(s)`);
				//     }, time));
				//     // await page.waitFor(hangtime);
				//     await page2.close()
				// }
				// }
				// // console.log(pageLinks);

			}
			console.log(`${iter} clicks performed`);
			console.log(`Browsed ${website} for ${browseTime(startTime)} seconds`);
		}



		// await page.waitFor(60000);
		await browser.close();
	}
	catch (e) {
		console.log('My Error:\n', e);
		console.log('Navigating Back One Page:')
		await page.goBack()
	}
})();